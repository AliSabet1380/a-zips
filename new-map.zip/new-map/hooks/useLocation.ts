import { useEffect, useState } from "react";
import { City } from "../types";
import { getData } from "@/utils/IndexDb";

export const useLocation = () => {
  const [names, setNames] = useState<string | null>(null);
  const [city, setCity] = useState<City[]>([]);
  const [coords, setCoords] = useState<[number, number]>();
  const [showuser, setShowUser] = useState(false);
  const [cst, setCst] = useState<string | undefined>();
  const [os, setOs] = useState<string | undefined>();

  const getos = async () => {
    const stored = await getData(7);
    if (typeof stored?.array === "string") {
      setOs(stored.array);
    } else {
      setOs("-1");
    }
  };

  const getcs = async () => {
    const stored = await getData(8);
    if (typeof stored?.array === "string") {
      setCst(stored.array);
    } else {
      setCst("-1");
    }
  };

  const getUserLocation = async () => {
    return new Promise<void>((resolve, reject) => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setShowUser(true);
            setCoords([position.coords.latitude, position.coords.longitude]);
            resolve();
          },
          (err) => {
            console.log(err);
            reject(err);
          }
        );
      } else {
        reject(new Error("Geolocation is not supported"));
      }
    });
  };

  useEffect(() => {
    getos();
    getcs();
  }, []);

  useEffect(() => {
    if (os) {
      // This will be handled by the parent component
    }
  }, [os]);

  useEffect(() => {
    if (cst) {
      // This will be handled by the parent component
    }
  }, [cst]);

  return {
    names,
    setNames,
    city,
    setCity,
    coords,
    showuser,
    setShowUser,
    getUserLocation,
    os,
    cst,
  };
};

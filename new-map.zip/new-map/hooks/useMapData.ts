"use client";

import { useMemo } from "react";
import { useProperties } from "@/hooks/use-properties";
import { useCategories } from "@/hooks/use-categories";
import { useProvinces } from "@/hooks/use-provinces";

export const useMapData = () => {
  // Use custom hooks for data fetching
  const { data: propertiesData, isLoading: propertiesLoading } =
    useProperties();
  const { data: categoriesData, isLoading: categoriesLoading } =
    useCategories();
  const { data: provincesData, isLoading: provincesLoading } = useProvinces();

  // Extract data from responses
  const properties = useMemo(() => {
    return propertiesData?.data || [];
  }, [propertiesData]);

  const categories = useMemo(() => {
    return categoriesData?.data || [];
  }, [categoriesData]);

  const provinces = useMemo(() => {
    return provincesData?.msg?.[0]?.provinces || [];
  }, [provincesData]);

  const isLoading = propertiesLoading || categoriesLoading || provincesLoading;

  return {
    properties,
    categories,
    provinces,
    isLoading,
  };
};

import { useEffect, useState } from "react";
import { PropertyItem } from "../types";
import { saveData } from "@/utils/IndexDb";

export const useSearch = (
  property: PropertyItem[],
  selectedCategory2Id?: number,
  selectedCategory3Id?: number
) => {
  const [searchString, setSearchString] = useState<string>("");
  const [debouncedSearch, setDebouncedSearch] = useState<string>(searchString);
  const [isFocused, setIsFocused] = useState<boolean>(false);
  const [properties, setProperties] = useState<PropertyItem[]>(property);
  const [OstanId, setOstanId] = useState<string>("-1");
  const [cityId, setCityID] = useState<string>("-1");
  const [categoryId, setCategoryId] = useState<number>(0);

  // Debounce search
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(searchString);
    }, 500);
    return () => clearTimeout(handler);
  }, [searchString]);

  // Filter properties based on search criteria - INTERSECTION approach (AND logic)
  useEffect(() => {
    let filteredResults: PropertyItem[] = [...property];

    // Apply location filter (province) - if active, filter matching items
    if (OstanId !== "-1") {
      filteredResults = filteredResults.filter((item) => {
        return item.province.name.toLowerCase().includes(OstanId.toLowerCase());
      });
    }

    // Apply location filter (city) - if active, filter matching items
    if (cityId !== "-1") {
      filteredResults = filteredResults.filter((item) => {
        return item.city.name.toLowerCase().includes(cityId.toLowerCase());
      });
    }

    // Apply category filter - if active, filter matching items
    if (categoryId !== 0) {
      filteredResults = filteredResults.filter((item) => {
        return Number(item.category1_id) === categoryId;
      });
    }

    // Apply subcategory2 filter - if active, filter matching items
    if (selectedCategory2Id) {
      filteredResults = filteredResults.filter((item) => {
        return Number(item.category2_id) === selectedCategory2Id;
      });
    }

    // Apply subcategory3 filter - if active, filter matching items
    if (selectedCategory3Id) {
      filteredResults = filteredResults.filter((item) => {
        return Number(item.category3_id) === selectedCategory3Id;
      });
    }

    // Apply search filter - if active, filter matching items
    if (debouncedSearch !== "") {
      const searchTerm = debouncedSearch.toLowerCase();
      filteredResults = filteredResults.filter((item) => {
        // Search in multiple fields
        const searchableFields = [
          item.name, // Property name
          item.formatted_address, // Address
          item.province.name, // Province name
          item.city.name, // City name
          item.user.first_name, // User first name
          item.user.last_name, // User last name
          item.category1?.name || "", // Category name
          item.user_defined_category || "", // User defined category
        ];

        // Check if any field contains the search term
        return searchableFields.some(
          (field) => field && field.toLowerCase().includes(searchTerm)
        );
      });
    }

    // Sort by ID (newest first)
    filteredResults.sort((a, b) => b.id - a.id);

    setProperties(filteredResults);
  }, [
    property,
    OstanId,
    cityId,
    categoryId,
    selectedCategory2Id,
    selectedCategory3Id,
    debouncedSearch,
  ]);

  // Save filtered results
  useEffect(() => {
    const saves = async () => {
      if (
        debouncedSearch !== "" ||
        categoryId !== 0 ||
        OstanId !== "-1" ||
        cityId !== "-1" ||
        selectedCategory2Id ||
        selectedCategory3Id
      ) {
        await saveData(20, properties);
      }
    };
    saves();
  }, [
    properties,
    debouncedSearch,
    categoryId,
    OstanId,
    cityId,
    selectedCategory2Id,
    selectedCategory3Id,
  ]);

  return {
    searchString,
    setSearchString,
    debouncedSearch,
    isFocused,
    setIsFocused,
    properties,
    OstanId,
    setOstanId,
    cityId,
    setCityID,
    categoryId,
    setCategoryId,
    isFilteredOrSearched:
      debouncedSearch !== "" ||
      categoryId !== 0 ||
      OstanId !== "-1" ||
      cityId !== "-1" ||
      !!selectedCategory2Id ||
      !!selectedCategory3Id,
  };
};

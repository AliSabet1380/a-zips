export interface Province {
  id: number;
  name: string;
  cities?: City[];
}

export interface City {
  id: number;
  name: string;
}

export interface PropertyFile {
  title: string;
  address: string;
}

export interface PropertyItem {
  id: number;
  formatted_address: string;
  user_defined_category: null | string;
  created_at: string;
  harvesting_time: string | null;
  city: City;
  user: {
    phone_number: string;
    first_name: string;
    last_name: string;
    account_status?: string;
  };
  province_id: number | string;
  province: Province;
  city_id?: number | string;
  is_favorite: number;
  name: string;
  category1_id: number | string;
  category1: { id: number; name?: string };
  category2_id?: number | string;
  category3_id?: number | string;
  files: PropertyFile[];
  latitude: number;
  longitude: number;
  area: number;
}

export interface Category4 {
  id: number;
  category1_id: number;
  category2_id: number;
  category3_id: number;
  name: string;
  icon: string | null;
  purpose: string | null;
  description: string | null;
  deleted_at: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export interface Category3 {
  id: number;
  category1_id: number;
  category2_id: number;
  name: string;
  icon: string | null;
  purpose: string | null;
  description: string | null;
  deleted_at: string | null;
  created_at: string | null;
  updated_at: string | null;
  category4s: Category4[];
}

export interface Category2 {
  id: number;
  category1_id: number;
  name: string;
  icon: string | null;
  purpose: string | null;
  description: string | null;
  deleted_at: string | null;
  created_at: string | null;
  updated_at: string | null;
  category3s: Category3[];
}

export interface Category {
  id: number;
  name: string;
  icon: string;
  purpose: string | null;
  description: string | null;
  deleted_at: string | null;
  created_at: string | null;
  updated_at: string | null;
  category2s: Category2[];
}

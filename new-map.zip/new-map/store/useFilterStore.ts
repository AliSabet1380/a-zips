import { create } from "zustand";

interface FilterState {
  isFilterOpen: boolean;
  setIsFilterOpen: (open: boolean) => void;
  toggleFilter: () => void;
  activeFiltersCount: number;
  setActiveFiltersCount: (count: number) => void;
}

export const useFilterStore = create<FilterState>((set) => ({
  isFilterOpen: false,
  setIsFilterOpen: (open: boolean) => set({ isFilterOpen: open }),
  toggleFilter: () => set((state) => ({ isFilterOpen: !state.isFilterOpen })),
  activeFiltersCount: 0,
  setActiveFiltersCount: (count: number) => set({ activeFiltersCount: count }),
}));

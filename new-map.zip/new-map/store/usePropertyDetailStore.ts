import { create } from "zustand";
import { PropertyItem } from "../types";

interface PropertyDetailState {
  isVisible: boolean;
  selectedProperty: PropertyItem | null;
  showPropertyDetail: (property: PropertyItem) => void;
  hidePropertyDetail: () => void;
}

export const usePropertyDetailStore = create<PropertyDetailState>((set) => ({
  isVisible: false,
  selectedProperty: null,
  showPropertyDetail: (property: PropertyItem) =>
    set({
      isVisible: true,
      selectedProperty: property,
    }),
  hidePropertyDetail: () =>
    set({
      isVisible: false,
      selectedProperty: null,
    }),
}));

import { create } from "zustand";

interface SwiperState {
  isVisible: boolean;
  setIsVisible: (visible: boolean) => void;
  toggleSwiper: () => void;
}

export const useSwiperStore = create<SwiperState>((set) => ({
  isVisible: false,
  setIsVisible: (visible: boolean) => set({ isVisible: visible }),
  toggleSwiper: () => set((state) => ({ isVisible: !state.isVisible })),
}));

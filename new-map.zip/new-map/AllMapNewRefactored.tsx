"use client";
import React, { useEffect, useState, useMemo } from "react";
import { motion } from "framer-motion";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import Cookies from "js-cookie";
import Nv from "../../Navigation/Nv2";
import { useMapData } from "./hooks/useMapData";
import { useSearch } from "./hooks/useSearch";
import { useLocation } from "./hooks/useLocation";
import { useFavorites } from "@/hooks/use-favorites";
import { useFavoriteMutation } from "@/hooks/use-favorite-mutation";
import { SearchBar } from "./components/SearchBar";
import { LocationSelector } from "./components/LocationSelector";
import { CategoryFilter } from "./components/CategoryFilter";
import { ActiveFilters } from "./components/ActiveFilters";
import { MapComponent } from "./components/MapComponent";
import { MapControls } from "./components/MapControls";
import { LayerSelector } from "./components/LayerSelector";
import { useSwiperStore } from "./store/useSwiperStore";
import { useFilterStore } from "./store/useFilterStore";
import { Category as CategoryType } from "./types";
import Swal from "sweetalert2";
import PropertyDetailOverlay from "./components/PropertyDetailOverlay";

function AllMapNewRefactored(): JSX.Element {
  // Data hooks
  const { properties, categories, provinces, isLoading } = useMapData();
  const { data: favoritesData } = useFavorites();
  const favoriteMutation = useFavoriteMutation();

  // Subcategory filtering state
  const [selectedCategory2Id, setSelectedCategory2Id] = useState<
    number | undefined
  >();
  const [selectedCategory3Id, setSelectedCategory3Id] = useState<
    number | undefined
  >();

  // Search and filtering
  const {
    searchString,
    setSearchString,
    debouncedSearch,
    isFocused,
    setIsFocused,
    properties: filteredProperties,
    OstanId,
    setOstanId,
    cityId,
    setCityID,
    categoryId,
    setCategoryId,
    isFilteredOrSearched,
  } = useSearch(properties, selectedCategory2Id, selectedCategory3Id);

  // Location management
  const {
    names,
    setNames,
    city,
    setCity,
    coords,
    showuser,
    getUserLocation,
    os,
    cst,
  } = useLocation();

  // UI state
  const [isOpen, setOpen] = useState<boolean>(false);
  const [zoomNumber, setZoomNumber] = useState<number>(5.7);
  const [isinstall, setInstall] = useState<boolean>();
  const [showmodal, setShowmodal] = useState<boolean>(false);
  const [currentMapStyle, setCurrentMapStyle] = useState("standard");

  const router = useRouter();
  const { setIsVisible, isVisible } = useSwiperStore();
  const { setActiveFiltersCount } = useFilterStore();
  const params = useSearchParams();
  const pathname = usePathname();
  const getShow = params.get("search");

  // Filter categories
  const filtered: CategoryType[] = categories.filter((item: CategoryType) => {
    return [1, 2, 4, 7].includes(item.id);
  });

  // Extract bookmarked items from favorites data
  const bookmarkedItemsSet = useMemo(() => {
    const favoriteIds = new Set<number>();
    if (favoritesData?.data && Array.isArray(favoritesData.data)) {
      favoritesData.data.forEach(
        (favorite: { property_id?: number; advertisement_id?: number }) => {
          if (favorite.property_id) {
            favoriteIds.add(favorite.property_id);
          }
        }
      );
    }
    return favoriteIds;
  }, [favoritesData]);

  // Handle location updates
  useEffect(() => {
    if (OstanId !== "-1") {
      const selectedProvince = provinces.find(
        (item: {
          id: number;
          name: string;
          cities?: { id: number; name: string }[];
        }) => item.id === Number(OstanId) || item.name === OstanId
      );
      setCity(selectedProvince?.cities || []);
    }
  }, [OstanId, provinces, setCity]);

  useEffect(() => {
    if (OstanId !== "-1" && cityId === "-1") {
      const selected = provinces.find(
        (item: { name: string }) => item.name == OstanId
      );
      setNames(selected ? selected.name : null);
    } else if (cityId !== "-1") {
      setNames(cityId);
    }
  }, [OstanId, cityId, provinces, setNames]);

  useEffect(() => {
    if (OstanId !== "-1") {
      const selected = provinces.find(
        (item: { name: string; cities?: { id: number; name: string }[] }) =>
          item.name == OstanId
      );
      setCity(selected?.cities || []);
    } else {
      setNames("ایران");
    }
  }, [OstanId, provinces, setCity, setNames]);

  // Handle stored location data
  useEffect(() => {
    if (os) {
      setOstanId(os);
    }
  }, [os, setOstanId]);

  useEffect(() => {
    if (cst) {
      setCityID(cst);
    }
  }, [cst, setCityID]);

  // Handle city reset when province changes
  useEffect(() => {
    if (OstanId == "-1") {
      setCityID("-1");
    }
  }, [OstanId, setCityID]);

  // Handle PWA detection
  useEffect(() => {
    if (typeof window !== "undefined") {
      const ispwa = window.matchMedia("(display-mode : standalone)").matches;
      setInstall(ispwa);
    }
  }, []);

  // Handle search modal
  useEffect(() => {
    if (getShow == "true") {
      setShowmodal(true);
      setIsVisible(true); // Set swiper as visible in Zustand store
    } else {
      setShowmodal(false);
      setIsVisible(false); // Set swiper as hidden in Zustand store
    }
  }, [getShow, setIsVisible]);

  // Handle route tracking
  useEffect(() => {
    if (pathname) {
      sessionStorage.setItem("previousRoute", pathname);
    }
  }, [pathname]);

  // Handle back button
  useEffect(() => {
    const handleBackButton = (event: PopStateEvent) => {
      if (showmodal) {
        event.preventDefault?.();
        router.push("/");
      } else {
        if (window.history.length > 1) {
          window.history.back();
        } else {
          console.log("صفحه قبلی وجود ندارد!");
        }
      }
    };
    if (showmodal) {
      window.history.pushState(null, "", window.location.pathname);
    }

    window.addEventListener("popstate", handleBackButton);

    return () => {
      window.removeEventListener("popstate", handleBackButton);
    };
  }, [showmodal, router]);

  // Handle user location zoom
  const handleGetUserLocation = async () => {
    try {
      await getUserLocation();
      setZoomNumber(18);
    } catch (error) {
      console.error("Error getting user location:", error);
      alert("خطا در دریافت موقعیت شما. لطفاً مجدداً تلاش کنید.");
    }
  };

  // Handle subcategory selection
  const handleSubcategorySelect = (
    categoryId: number,
    level: "category2" | "category3"
  ) => {
    if (level === "category2") {
      setSelectedCategory2Id(categoryId);
      setSelectedCategory3Id(undefined); // Reset category3 when category2 is selected
    } else if (level === "category3") {
      setSelectedCategory3Id(categoryId);
    }
  };

  // Clear subcategory filters
  const handleClearSubcategories = () => {
    setSelectedCategory2Id(undefined);
    setSelectedCategory3Id(undefined);
  };

  // Clear category filter
  const handleClearCategory = () => {
    setCategoryId(0);
  };

  // Clear location filter
  const handleClearLocation = () => {
    setOstanId("-1");
    setCityID("-1");
  };

  // Clear search filter
  const handleClearSearch = () => {
    setSearchString("");
  };

  // Clear all filters
  const handleClearAll = () => {
    setCategoryId(0);
    setSelectedCategory2Id(undefined);
    setSelectedCategory3Id(undefined);
    setOstanId("-1");
    setCityID("-1");
    setSearchString("");
  };

  // Update active filters count
  useEffect(() => {
    const activeCount = [
      categoryId !== 0,
      selectedCategory2Id !== undefined,
      selectedCategory3Id !== undefined,
      OstanId !== "-1",
      cityId !== "-1",
      searchString !== "",
    ].filter(Boolean).length;

    setActiveFiltersCount(activeCount);
  }, [
    categoryId,
    selectedCategory2Id,
    selectedCategory3Id,
    OstanId,
    cityId,
    searchString,
    setActiveFiltersCount,
  ]);

  // Use the filtered properties directly from useSearch hook
  const finalFilteredProperties = filteredProperties;

  // Favorite submission
  const tk = Cookies.get("tokens");
  const submitFavorite = async (id: number | string, isFavorite: boolean) => {
    const favoriteData = { property_id: Number(id) };

    if (!tk) {
      Swal.fire({
        timer: 3000,
        title: "لطفا وارد حساب کاربری خود شوید",
        icon: "warning",
      });
      return;
    }

    try {
      await favoriteMutation.mutateAsync(favoriteData);
      console.log(
        `Property ${id} ${isFavorite ? "unbookmarked" : "bookmarked"}`
      );
    } catch (error) {
      console.log(error);
    }
  };

  if (isLoading) {
    return <div className="loaderpre"></div>;
  }

  if (
    provinces !== undefined &&
    categories !== undefined &&
    properties !== undefined
  ) {
    return (
      <div className="relative mx-auto sm:w-96 sm:border">
        <div className="mx-auto max-w-[1400px]">
          {!showmodal ? (
            <div>
              {/* Top Navigation Bar */}
              <div
                style={{ userSelect: "none" }}
                className="fixed top-0 z-20 mx-auto flex w-full flex-row items-center justify-between p-2 sm:w-96"
              >
                <SearchBar
                  searchString={searchString}
                  setSearchString={setSearchString}
                  isFocused={isFocused}
                  setIsFocused={setIsFocused}
                />
                <LocationSelector
                  isOpen={isOpen}
                  setOpen={setOpen}
                  names={names}
                  Ostan={provinces}
                  city={city}
                  OstanId={OstanId}
                  setOstanId={setOstanId}
                  cityId={cityId}
                  setCityID={setCityID}
                />
              </div>

              {/* Main Map Area */}
              <motion.div
                initial={{ opacity: 0, scale: 1 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{
                  duration: 0.5,
                  delay: 0.2,
                  ease: [0, 0.71, 0.2, 1.01],
                }}
                className="relative z-10 mx-auto mt-14 w-full sm:w-full"
              >
                <div className="absolute top-1 w-full" style={{ zIndex: 500 }}>
                  <CategoryFilter
                    categoryId={categoryId}
                    setCategoryId={setCategoryId}
                    filtered={filtered}
                    onSubcategorySelect={handleSubcategorySelect}
                    selectedCategory2Id={selectedCategory2Id}
                    selectedCategory3Id={selectedCategory3Id}
                  />
                </div>

                {/* Active Filters Display */}
                <div
                  className="absolute top-14 w-full px-4"
                  style={{ zIndex: 400 }}
                >
                  <ActiveFilters
                    categoryId={categoryId}
                    selectedCategory2Id={selectedCategory2Id}
                    selectedCategory3Id={selectedCategory3Id}
                    OstanId={OstanId}
                    cityId={cityId}
                    searchString={searchString}
                    filtered={filtered}
                    provinces={provinces}
                    onClearCategory={handleClearCategory}
                    onClearSubcategories={handleClearSubcategories}
                    onClearLocation={handleClearLocation}
                    onClearSearch={handleClearSearch}
                    onClearAll={handleClearAll}
                  />
                </div>
                <div>
                  <MapComponent
                    zoomNumber={zoomNumber}
                    isinstall={isinstall || false}
                    coords={coords}
                    showuser={showuser}
                    properties={finalFilteredProperties}
                    submitFavorite={submitFavorite}
                    currentMapStyle={currentMapStyle}
                    bookmarkedItems={bookmarkedItemsSet}
                    isFilteredOrSearched={isFilteredOrSearched}
                  />
                  {!isVisible && (
                    <>
                      <MapControls
                        getUserLocation={handleGetUserLocation}
                        properties={finalFilteredProperties}
                        debouncedSearch={debouncedSearch}
                      />
                      <LayerSelector
                        currentMapStyle={currentMapStyle}
                        onMapStyleChange={setCurrentMapStyle}
                      />
                    </>
                  )}
                </div>
              </motion.div>
            </div>
          ) : null}
        </div>
        {/* Swiper for filtered/search results is now handled by MarkersNew */}
        <Nv />
        <PropertyDetailOverlay />
      </div>
    );
  }

  return <div className="loaderpre"></div>;
}

export default AllMapNewRefactored;

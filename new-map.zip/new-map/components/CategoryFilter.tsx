"use client";
import React, { useState } from "react";
import Image from "next/image";
import { Category } from "../types";
import { SubcategoryModal } from "./SubcategoryModal";

interface CategoryFilterProps {
  categoryId: number;
  setCategoryId: (value: number) => void;
  filtered: Category[];
  loading?: boolean;
  onSubcategorySelect?: (
    categoryId: number,
    level: "category2" | "category3"
  ) => void;
  selectedCategory2Id?: number;
  selectedCategory3Id?: number;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  categoryId,
  setCategoryId,
  filtered,
  loading = false,
  onSubcategorySelect,
  selectedCategory2Id,
  selectedCategory3Id,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(
    null
  );

  const handleCategoryClick = (category: Category) => {
    // Check if the category has subcategories
    if (category.category2s && category.category2s.length > 0) {
      setSelectedCategory(category);
      setIsModalOpen(true);
    } else {
      // If no subcategories, directly set the category
      setCategoryId(category.id);
    }
  };

  const handleSubcategorySelect = (
    categoryId: number,
    level: "category2" | "category3"
  ) => {
    if (onSubcategorySelect) {
      onSubcategorySelect(categoryId, level);
    }
    setIsModalOpen(false);
    setSelectedCategory(null);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedCategory(null);
  };

  return (
    <>
      <div
        style={{ scrollbarWidth: "none" }}
        className="flex flex-row flex-nowrap gap-2 overflow-x-scroll p-2"
      >
        <div
          onClick={() => setCategoryId(0)}
          className={`cursor-pointer whitespace-nowrap rounded-2xl ${
            categoryId === 0
              ? "bg-reezAliGreen text-white"
              : "bg-white text-neutral-800"
          } flex items-center justify-center px-4 py-2 text-sm shadow-lg hover:shadow-xl transition-all`}
        >
          همه
        </div>
        {filtered.map(
          (item, index) =>
            index < 5 && (
              <div
                onClick={() => handleCategoryClick(item)}
                key={index}
                className={`w-auto cursor-pointer whitespace-nowrap rounded-2xl ${
                  categoryId === item.id
                    ? "bg-reezAliGreen text-white"
                    : "bg-white text-neutral-800"
                } flex items-center justify-center py-2 px-4 shadow-lg hover:shadow-xl transition-all`}
              >
                <div className="flex items-center justify-center gap-2">
                  {loading && categoryId === item.id ? (
                    <div className="loader4"></div>
                  ) : (
                    <>
                      <Image
                        alt="icon"
                        className={`rounded-full border border-reezAliGreen bg-white p-1 text-black ${
                          categoryId === item.id ? "bg-white" : "bg-reezAliGold"
                        }`}
                        width={24}
                        height={24}
                        src={process.env.NEXT_PUBLIC_URL + item.icon}
                      />
                      <span className="text-sm font-medium">{item.name}</span>
                    </>
                  )}
                </div>
              </div>
            )
        )}
      </div>

      <SubcategoryModal
        isOpen={isModalOpen}
        onClose={closeModal}
        selectedCategory={selectedCategory}
        onCategorySelect={handleSubcategorySelect}
        selectedCategory2Id={selectedCategory2Id}
        selectedCategory3Id={selectedCategory3Id}
      />
    </>
  );
};

import { LocateFixed, List } from "lucide-react";
import { useRouter } from "next/navigation";
import { PropertyItem } from "../types";

interface MapControlsProps {
  getUserLocation: () => void;
  properties: PropertyItem[];
  debouncedSearch: string;
}

export const MapControls: React.FC<MapControlsProps> = ({
  getUserLocation,
  properties,
  debouncedSearch,
}) => {
  const router = useRouter();

  return (
    <>
      <div
        onClick={() => getUserLocation()}
        style={{ zIndex: 10001 }}
        className="absolute bottom-[14rem] right-3 rounded-full bg-white p-2 shadow-lg"
      >
        <LocateFixed className="text-amber-900" size={28.5} />
      </div>
      <button
        onClick={() => {
          router.push("/land/all");
        }}
        className={`absolute bottom-[10.2rem]  right-[10px]  h-12 w-[9rem] rounded-full bg-reezAliGreen p-0 shadow-lg sm:right-[8px]`}
        style={{ zIndex: 10001 }}
      >
        <div className="flex items-center gap-4">
          <List className="relative right-3.5" size={18} color="white" />
          {debouncedSearch == "" ? (
            <span className="text-sm text-white whitespace-nowrap">
              لیست محصولات
            </span>
          ) : (
            <span className="text-sm text-white whitespace-nowrap">
              لیست جستجو
            </span>
          )}
        </div>
        <span className="absolute -left-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full border-2 border-red-500 bg-white text-xs text-red-500 shadow-md">
          {properties?.length}
        </span>
      </button>
    </>
  );
};

export const mapStyles = {
  standard: {
    version: 8 as const,
    sources: {
      "mapbox-streets": {
        type: "raster" as const,
        tiles: [
          `https://api.mapbox.com/styles/v1/mapbox/streets-v11/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoiemltYWRldiIsImEiOiJjbHRmbWNzZWUwNTBzMmlvNWxxemxibmNkIn0._smmoJa2p-PkgquRI-q4sw`,
        ],
        tileSize: 256,
        attribution: "© Mapbox",
      },
    },
    layers: [
      {
        id: "mapbox-streets",
        type: "raster" as const,
        source: "mapbox-streets",
        minzoom: 0,
        maxzoom: 22,
      },
    ],
  },
  satellite: {
    version: 8 as const,
    sources: {
      "mapir-satellite": {
        type: "raster" as const,
        tiles: [
          `https://map.ir/raster/xyz/1.0.0/google:y@EPSG:900913@png/{z}/{x}/{y}.png?x-api-key=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjYxY2Y1MWVkYjBlOGVkOTU5OTUzM2MxYzJkZTlkNGI2NmUxNzI3ZThjNDJjMGRmZmMyYmY3ZjViMzI1YTgzM2Y5NTkxOTgwYjAxZDliZDFlIn0.eyJhdWQiOiIzMzI4NyIsImp0aSI6IjYxY2Y1MWVkYjBlOGVkOTU5OTUzM2MxYzJkZTlkNGI2NmUxNzI3ZThjNDJjMGRmZmMyYmY3ZjViMzI1YTgzM2Y5NTkxOTgwYjAxZDliZDFlIiwiaWF0IjoxNzUyMTQwNTE1LCJuYmYiOjE3NTIxNDA1MTUsImV4cCI6MTc1NDczMjUxNSwic3ViIjoiIiwic2NvcGVzIjpbImJhc2ljIl19.EHgD80mpFWSUpxJFHSo1fKt0HeH7M3M1ibCEjfLXADejOlDOsdBaaYpPsQGqMYq8R9z_16-au7V-vKfX5B6N0UMug_y-IfYkIQmViG7uFiLGyF33MpijxN9aDvV60sKobk0Vi1C3OWGxLLXcjryVnSIwk6L3XbUCQ_mJUDNN2kXPnfZ2bh9IOfO4jR48ZNzZLCeeYEzW84BkKYL0gfjUZku_x3Kd9LGjN26gZjY2yki87AZPRiKEwVu8MJDhghbDTai4VEcDMMHi0TpuAwPn6cHjPayaLqXn4q1eNoynw1rgsBw9c5MUXMBK8oTMc2nia-Q846hTubELpt3pnviEaQ`,
        ],
        tileSize: 256,
        attribution: "© map.ir",
      },
    },
    layers: [
      {
        id: "mapir-satellite",
        type: "raster" as const,
        source: "mapir-satellite",
        minzoom: 0,
        maxzoom: 22,
      },
    ],
  },
  openstreet: {
    version: 8 as const,
    sources: {
      openstreet: {
        type: "raster" as const,
        tiles: ["https://a.tile.openstreetmap.org/{z}/{x}/{y}.png"],
        tileSize: 256,
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      },
    },
    layers: [
      {
        id: "openstreet",
        type: "raster" as const,
        source: "openstreet",
        minzoom: 0,
        maxzoom: 22,
      },
    ],
  },
};

export const getMapStyle = (styleName: string) => {
  return mapStyles[styleName as keyof typeof mapStyles] || mapStyles.satellite;
};

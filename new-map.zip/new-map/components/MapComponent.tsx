import React, { useMemo, useRef, useEffect } from "react";
import { Map, Marker } from "react-map-gl/maplibre";
import "maplibre-gl/dist/maplibre-gl.css";
import type { MapRef } from "react-map-gl/maplibre";
import { PropertyItem } from "../types";
import { getMapStyle } from "./MapConfig";
import MarkersNew from "./MarkersNew";
import Image from "next/image";

interface MapComponentProps {
  zoomNumber: number;
  isinstall: boolean;
  coords: [number, number] | undefined;
  showuser: boolean;
  properties: PropertyItem[];
  submitFavorite: (id: number | string, isFavorite: boolean) => void;
  currentMapStyle?: string;
  bookmarkedItems?: Set<number>;
  isFilteredOrSearched?: boolean;
}

export const MapComponent: React.FC<MapComponentProps> = ({
  zoomNumber,
  isinstall,
  coords,
  showuser,
  properties,
  submitFavorite,
  currentMapStyle = "standard",
  bookmarkedItems = new Set(),
  isFilteredOrSearched,
}) => {
  const mapRef = useRef<MapRef | null>(null);

  // Fly to user location when coords change (smooth animation, no zoom change)
  useEffect(() => {
    if (coords && showuser && mapRef.current) {
      mapRef.current.flyTo({
        center: [coords[1], coords[0]],
        zoom: zoomNumber,
        duration: 1000, // Smooth animation
        essential: true, // This ensures the animation runs
      });
    }
  }, [coords, showuser, zoomNumber]);

  const memoizedMap = useMemo(() => {
    return (
      <Map
        ref={mapRef}
        initialViewState={{
          longitude: 52.571871602350356,
          latitude: 29.59319925338209,
          zoom: zoomNumber,
        }}
        style={
          isinstall
            ? { height: "100vh", width: "100%" }
            : { height: "92vh", width: "100%" }
        }
        mapStyle={getMapStyle(currentMapStyle)}
        attributionControl={false}
      >
        {coords && showuser && (
          <Marker longitude={coords[1]} latitude={coords[0]} anchor="bottom">
            <div className="w-8 h-8">
              <Image
                src="/ics/new/current.svg"
                alt="User Location"
                className="w-full h-full"
                width={100}
                height={100}
              />
            </div>
          </Marker>
        )}
        <MarkersNew
          submitFavorite={submitFavorite}
          properties={properties}
          bookmarkedItems={bookmarkedItems}
          isFilteredOrSearched={isFilteredOrSearched}
        />
      </Map>
    );
  }, [
    bookmarkedItems,
    zoomNumber,
    isinstall,
    coords,
    properties,
    currentMapStyle,
    showuser,
    submitFavorite,
    isFilteredOrSearched,
  ]);

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        willChange: "transform",
      }}
      className="relative h-full w-full"
    >
      {memoizedMap}
    </div>
  );
};

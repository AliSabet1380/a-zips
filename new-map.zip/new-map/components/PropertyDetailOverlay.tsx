import React from "react";
import { usePropertyDetailStore } from "../store/usePropertyDetailStore";
import PropertyDetail from "./PropertyDetail";
import { useSwiperStore } from "../store/useSwiperStore";

const PropertyDetailOverlay: React.FC = () => {
  const { isVisible, selectedProperty, hidePropertyDetail } =
    usePropertyDetailStore();
  const { setIsVisible } = useSwiperStore();

  if (!isVisible || !selectedProperty) {
    return null;
  }

  return (
    <div className="fixed bottom-16 left-4 right-4 z-[1000]">
      <div className="relative w-full">
        <PropertyDetail
          key={selectedProperty.id}
          property={selectedProperty}
          onClose={() => {
            hidePropertyDetail();
            setIsVisible(false);
          }}
        />
      </div>
    </div>
  );
};

export default PropertyDetailOverlay;

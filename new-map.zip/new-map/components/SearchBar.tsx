import { Search, X } from "lucide-react";
import { useRef } from "react";

interface SearchBarProps {
  searchString: string;
  setSearchString: (value: string) => void;
  isFocused: boolean;
  setIsFocused: (value: boolean) => void;
  loading?: boolean;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchString,
  setSearchString,
  isFocused,
  setIsFocused,
  loading = false,
}) => {
  const searchInputRef = useRef<HTMLInputElement>(null);
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (searchInputRef.current) {
      setSearchString(searchInputRef.current.value);
      searchInputRef.current.value = "";
      searchInputRef.current.blur();
    }
  };
  return (
    <div
      style={{ width: "76%" }}
      className="flex h-10 border items-center justify-between rounded-md bg-white px-4 py-2 shadow-lg"
    >
      <div className="flex sm:hidden">
        <div className="relative flex -translate-y-1/2 transform items-center justify-center">
          <Search
            className={`absolute -top-3 h-6 w-6 text-gray-500 transition-all duration-500 ${
              isFocused
                ? "translate-x-0 opacity-100"
                : "translate-x-5 opacity-0"
            }`}
          />
        </div>
      </div>
      <form onSubmit={handleSubmit} className="flex">
        <input
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          ref={searchInputRef}
          type="search"
          style={{ width: "240px", fontSize: "16px" }}
          placeholder="جستجو محصول یا کشاورز..."
          className="h-8 border border-white bg-white focus:px-3 focus:outline-none focus-visible:ring-[#fff]"
        />
        {!loading && searchString && (
          <X
            onClick={() => setSearchString("")}
            className="relative -right-[0.1rem] top-1.5 h-5 w-5 "
          />
        )}
      </form>
    </div>
  );
};

"use client";
import React, { useState } from "react";
import { Dialog } from "@headlessui/react";
import { X, ChevronRight } from "lucide-react";
import Image from "next/image";
import { Category } from "../types";

interface SubcategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCategory: Category | null;
  onCategorySelect: (
    categoryId: number,
    level: "category2" | "category3"
  ) => void;
  selectedCategory2Id?: number;
  selectedCategory3Id?: number;
}

export const SubcategoryModal: React.FC<SubcategoryModalProps> = ({
  isOpen,
  onClose,
  selectedCategory,
  onCategorySelect,
  selectedCategory2Id,
  selectedCategory3Id,
}) => {
  const [expandedCategory2, setExpandedCategory2] = useState<number | null>(
    null
  );

  const handleCategory2Click = (category2Id: number) => {
    if (expandedCategory2 === category2Id) {
      setExpandedCategory2(null);
    } else {
      setExpandedCategory2(category2Id);
    }
  };

  const handleCategory3Click = (category3Id: number) => {
    onCategorySelect(category3Id, "category3");
    onClose();
  };

  const handleCategory2Select = (category2Id: number) => {
    onCategorySelect(category2Id, "category2");
    onClose();
  };

  if (!selectedCategory) return null;

  return (
    <Dialog open={isOpen} onClose={onClose} className="relative z-50">
      <div className="fixed inset-0 bg-black/30" aria-hidden="true" />

      <div className="fixed inset-0 flex items-center justify-center p-4">
        <Dialog.Panel className="mx-auto max-w-md w-full bg-white rounded-2xl shadow-xl">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200">
            <div className="flex items-center gap-3">
              <Image
                alt="icon"
                className="rounded-full border border-reezAliGreen bg-white p-1"
                width={32}
                height={32}
                src={process.env.NEXT_PUBLIC_URL + selectedCategory.icon}
              />
              <Dialog.Title className="text-lg font-bold text-gray-900">
                {selectedCategory.name}
              </Dialog.Title>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X size={20} className="text-gray-500" />
            </button>
          </div>

          {/* Content */}
          <div className="p-4 max-h-96 overflow-y-auto">
            {selectedCategory.category2s.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                زیرمجموعه‌ای برای این دسته‌بندی وجود ندارد
              </div>
            ) : (
              <div className="space-y-2">
                {selectedCategory.category2s.map((category2) => (
                  <div
                    key={category2.id}
                    className="border border-gray-200 rounded-lg"
                  >
                    {/* Category2 Header */}
                    <div className="flex items-center justify-between p-3 hover:bg-gray-50 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div
                          onClick={() => handleCategory2Select(category2.id)}
                          className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                            selectedCategory2Id === category2.id
                              ? "bg-reezAliGreen text-white"
                              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                          }`}
                        >
                          {category2.name}
                        </div>
                      </div>
                      {category2.category3s.length > 0 && (
                        <button
                          onClick={() => handleCategory2Click(category2.id)}
                          className="p-1 hover:bg-gray-200 rounded-full transition-colors"
                        >
                          <ChevronRight
                            size={16}
                            className={`text-gray-500 transition-transform ${
                              expandedCategory2 === category2.id
                                ? "rotate-90"
                                : ""
                            }`}
                          />
                        </button>
                      )}
                    </div>

                    {/* Category3 List */}
                    {expandedCategory2 === category2.id &&
                      category2.category3s.length > 0 && (
                        <div className="border-t border-gray-200 bg-gray-50">
                          <div className="p-3 space-y-2">
                            {category2.category3s.map((category3) => (
                              <div
                                key={category3.id}
                                onClick={() =>
                                  handleCategory3Click(category3.id)
                                }
                                className={`px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                                  selectedCategory3Id === category3.id
                                    ? "bg-reezAliGreen text-white"
                                    : "bg-white text-gray-700 hover:bg-gray-100"
                                }`}
                              >
                                <span className="text-sm font-medium">
                                  {category3.name}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-gray-200">
            <button
              onClick={onClose}
              className="w-full py-2 px-4 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
            >
              بستن
            </button>
          </div>
        </Dialog.Panel>
      </div>
    </Dialog>
  );
};

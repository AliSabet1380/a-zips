"use client";
import React, { useEffect, useState } from "react";
import { Marker, useMap } from "react-map-gl/maplibre";
import { Drawer } from "vaul";
import moment from "jalali-moment";
import { formatCurrency } from "@/utils/common";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import Link from "next/link";
import { Bookmark, BookmarkCheck, ChevronDown, Phone } from "lucide-react";
import { useRouter } from "next/navigation";
import { useSwiperStore } from "../store/useSwiperStore";
import { usePropertyDetailStore } from "../store/usePropertyDetailStore";
import type { PropertyItem } from "../types";
import Image from "next/image";

interface MarkersNewProps {
  properties: PropertyItem[];
  submitFavorite: (id: number | string, isFavorite: boolean) => void;
  bookmarkedItems?: Set<number>;
  isFilteredOrSearched?: boolean;
}

const MarkersNew: React.FC<MarkersNewProps> = ({
  properties,
  submitFavorite,
  bookmarkedItems = new Set(),
  isFilteredOrSearched = false,
}) => {
  const { current: map } = useMap();
  const { setIsVisible, isVisible } = useSwiperStore();
  const [markerInfo, setMarkerInfo] = useState<PropertyItem | null>(null);
  const [active, setActive] = useState<number | null>(null);
  const [modalState, setModalState] = useState<boolean>(false);
  const [center, setCenterMarker] = useState<PropertyItem | null>(null);
  const [zoom, setZoom] = useState<number>(0);
  const router = useRouter();
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const {
    showPropertyDetail,
    isVisible: isPropertyDetailVisible,
    selectedProperty,
  } = usePropertyDetailStore();

  useEffect(() => {
    if (map) {
      const handleZoomChange = () => {
        setZoom(map.getZoom());
      };

      map.on("zoomend", handleZoomChange);

      return () => {
        map.off("zoomend", handleZoomChange);
      };
    }
  }, [map]);

  useEffect(() => {
    const updateCenter = () => {
      if (!map) return;

      const mapCenter = map.getCenter();
      let closestMarker: PropertyItem | null = null;
      let closestDistance = Infinity;

      properties.forEach((location: PropertyItem) => {
        const distance = Math.sqrt(
          Math.pow(mapCenter.lat - location.latitude, 2) +
            Math.pow(mapCenter.lng - location.longitude, 2)
        );

        if (distance < closestDistance) {
          closestDistance = distance;
          closestMarker = location;
        }
      });

      setCenterMarker(closestMarker);
    };

    if (map) {
      map.on("moveend", updateCenter);
      updateCenter();

      return () => {
        map.off("moveend", updateCenter);
      };
    }
  }, [map, properties]);

  // Auto-open modal on search/filter and handle filter removal
  useEffect(() => {
    if (isFilteredOrSearched && properties.length > 0) {
      setMarkerInfo((prev) =>
        prev && prev.id === properties[0].id ? prev : properties[0]
      );
      setModalState(true);
      setIsVisible(true);
      if (map) {
        map.easeTo({
          center: [properties[0].longitude, properties[0].latitude],
          duration: 1000,
          essential: true,
        });
      }
    } else if (isFilteredOrSearched && properties.length === 0) {
      setMarkerInfo(null);
      setActiveIndex(null);
      setModalState(false);
      setIsVisible(false);
    } else if (!isFilteredOrSearched) {
      // When no filters are active, hide the swiper and reset state
      setMarkerInfo(null);
      setActiveIndex(null);
      setModalState(false);
      setIsVisible(false);
    }
  }, [isFilteredOrSearched, properties, map]);

  // Reset activeIndex when swiper becomes invisible
  useEffect(() => {
    if (!isVisible) {
      setActiveIndex(null);
    }
  }, [isVisible]);

  const getIconUrl = (item: PropertyItem, index: number) => {
    const noActive = active == null || active == 0;

    if (markerInfo?.id && noActive) {
      if (markerInfo?.id == item?.id) {
        return "/ics/new/landred.svg";
      }
    }

    if (active && active !== 0) {
      if (active === index + 1) {
        return "/ics/new/landred.svg";
      }
    }

    if (item?.category1?.id != 10) {
      let diff;
      if (item?.harvesting_time != null) {
        const inputDate = moment(item?.harvesting_time, "YYYY-MM-DD").startOf(
          "day"
        );
        const today = moment().startOf("day");

        diff = inputDate.diff(today, "days");
      }
      if (diff && diff > 10) {
        return "/ics/new/landgreen.svg";
      } else {
        return "/ics/new/landred.svg";
      }
    } else {
      return "/images/land2.svg";
    }
  };

  const [filtered, setFiltered] = useState<PropertyItem[]>([]);
  useEffect(() => {
    if (markerInfo != null && isFilteredOrSearched) {
      if (markerInfo?.category1?.id == 10) {
        const filtered = properties.filter(
          (item) => item.category1.id == markerInfo.category1.id
        );
        setFiltered(filtered);
      } else {
        const filtered = properties.filter((item) => item.category1?.id != 10);
        setFiltered(filtered);
      }
    } else {
      // When no filters are active or no markerInfo, clear filtered array
      setFiltered([]);
    }
  }, [markerInfo, properties, isFilteredOrSearched]);

  const [selectedmarks, setMarks] = useState<string>("");
  const renderHarvestStatus = (harvesting_time: string | null) => {
    if (!harvesting_time) return null;

    const inputDate = moment(harvesting_time, "YYYY-MM-DD").startOf("day");
    const today = moment().startOf("day");
    const futureDate = inputDate.clone();

    const diff = futureDate.diff(today, "days");

    return diff > 10 ? (
      <span className="text-newreezGreen font-semibold text-xs">
        {diff} روز باقی مانده تا برداشت
      </span>
    ) : (
      <span className="text-red-600 font-semibold text-xs">در حال برداشت</span>
    );
  };

  const handleCloseModal = () => {
    setModalState(false);
    setIsVisible(false);
    setActive(null);
    setMarkerInfo(null);
    setActiveIndex(null);
    // Don't clear filters when closing modal - only clear when explicitly requested
  };

  const handleMarkerClick = (item: PropertyItem) => {
    // If property detail overlay is already open, just update the property
    if (isPropertyDetailVisible && selectedProperty) {
      showPropertyDetail(item);
    } else {
      // Show PropertyDetail component when clicking on a pin for the first time
      showPropertyDetail(item);
      setIsVisible(true); // Hide other UI elements when PropertyDetail is shown
    }

    // Only show swiper when there are active filters/searches
    if (isFilteredOrSearched) {
      setMarkerInfo(item);
      setModalState(true);
    } else {
      // When no filters are active, don't show the swiper
      setMarkerInfo(null);
      setModalState(false);
      setActiveIndex(null);
    }

    if (map) {
      map.easeTo({
        center: [item.longitude, item.latitude],
        duration: 1000,
        essential: true,
      });
    }
  };

  return (
    <div>
      {properties.map((item: PropertyItem, index: number) => {
        return (
          <div key={item.id}>
            <Marker
              longitude={item.longitude}
              latitude={item.latitude}
              anchor="bottom"
              onClick={() => handleMarkerClick(item)}
            >
              <div className="cursor-pointer relative z-[10000]">
                <Image
                  width={32}
                  height={32}
                  src={getIconUrl(item, index)}
                  alt="marker"
                  className={
                    activeIndex !== null && index === activeIndex
                      ? "w-11 h-11"
                      : "w-8 h-8"
                  }
                />
                {zoom >= 11 && center && center.id === item.id && (
                  <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded text-xs shadow-md whitespace-nowrap">
                    {center?.name}
                  </div>
                )}
              </div>
            </Marker>
          </div>
        );
      })}

      {markerInfo && modalState && properties.length > 0 && (
        <Drawer.Root
          modal={false}
          dismissible={false}
          open={modalState}
          onOpenChange={handleCloseModal}
        >
          <Drawer.Portal>
            <Drawer.Overlay className="fixed inset-0 pointer-events-none" />
            <Drawer.Content className="fixed w-full bottom-[3.5rem] left-0  z-50 mt-24 flex h-fit flex-col rounded-t-[10px] outline-none">
              <div className="relative w-full overflow-hidden">
                <Swiper
                  loop={true}
                  spaceBetween={2}
                  slidesPerView="auto"
                  onSlideChange={(swiper) => {
                    if (!isVisible) return;
                    setActiveIndex(swiper.realIndex);

                    let targetProperty;
                    if (swiper.realIndex === 0) {
                      targetProperty = markerInfo;
                    } else {
                      targetProperty = filtered[swiper.realIndex];
                    }
                    if (targetProperty && map) {
                      map.easeTo({
                        center: [
                          targetProperty.longitude,
                          targetProperty.latitude,
                        ],
                        zoom: 7,
                        duration: 1000,
                      });
                    }
                  }}
                  centeredSlides={true}
                  className="!overflow-visible"
                  style={{
                    paddingLeft: "calc(50% - 160px)",
                    paddingRight: "calc(50% - 160px)",
                  }}
                >
                  <div className="flex">
                    <SwiperSlide className="sw2" style={{ width: "460px" }}>
                      <div className="flex-1  rounded-2xl bg-white shadow-lg overflow-hidden mx-1 relative">
                        {selectedmarks == String(markerInfo.id) && (
                          <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-10 flex items-center justify-center rounded-2xl">
                            <div className="loader4"></div>
                          </div>
                        )}
                        <div className="flex items-center justify-between h-40">
                          {/* Content Section */}
                          <div className="w-[60%] h-full py-3.5 px-0.5 flex flex-col justify-between">
                            {/* Title and Info */}
                            <div>
                              <div
                                onClick={() =>
                                  router.push(`/land/${markerInfo.id}`)
                                }
                                className="cursor-pointer mb-2"
                              >
                                <h3 className="text-base font-bold text-gray-900 leading-tight hover:text-reezAliGreen transition-colors">
                                  {markerInfo.name.length > 30
                                    ? markerInfo.name.slice(0, 30) + "..."
                                    : markerInfo.name}
                                </h3>
                              </div>

                              {/* Location & Area */}
                              <div className="flex items-center gap-2 text-xs text-gray-600 mb-1">
                                <span className="font-semibold">
                                  {markerInfo?.province?.name} -{" "}
                                  {markerInfo?.city?.name}
                                </span>
                                <span className="text-gray-400 font-semibold">
                                  •
                                </span>
                                <span className="font-semibold">
                                  {markerInfo.area !== null
                                    ? (markerInfo.area / 10000).toFixed(1)
                                    : 0}{" "}
                                  هکتار
                                </span>
                              </div>

                              {/* Harvest Status */}
                              {markerInfo.harvesting_time && (
                                <div className="mb-2">
                                  <div className="flex items-center gap-1  rounded-full text-xs bg-green-100 text-green-700">
                                    <span>🌾</span>
                                    <span>
                                      {renderHarvestStatus(
                                        markerInfo.harvesting_time
                                      )}
                                    </span>
                                  </div>
                                </div>
                              )}
                            </div>

                            {/* Action Buttons */}
                            <div className="flex gap-1">
                              <Link
                                onClick={() => setMarks(String(markerInfo.id))}
                                href={`/land/${markerInfo.id}`}
                                className="flex-1 bg-reezAliGreen hover:bg-reezAliGreen/90 text-white py-2.5 px-3 rounded-lg font-semibold text-xs transition-colors flex items-center justify-center gap-1"
                              >
                                <span>جزئیات</span>
                                <ChevronDown size={12} />
                              </Link>

                              {markerInfo.user.account_status !== "مشغول" ? (
                                <a
                                  href={`tel:+98${markerInfo?.user?.phone_number?.slice(
                                    1,
                                    12
                                  )}`}
                                  className="bg-blue-50 hover:bg-blue-100 text-blue-700 py-2.5 px-3 rounded-lg font-semibold text-xs transition-colors flex items-center justify-center gap-1"
                                >
                                  <Phone size={12} />
                                  <span>تماس</span>
                                </a>
                              ) : (
                                <span className="bg-gray-100 text-gray-500 py-2.5 px-3 rounded-lg font-semibold text-xs flex items-center justify-center gap-1">
                                  <Phone size={12} />
                                  <span>مشغول</span>
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Image Section */}
                          <div className="relative w-[40%] h-full ">
                            {markerInfo.files?.length > 0 ? (
                              <div
                                onClick={() =>
                                  router.push(`/land/${markerInfo.id}`)
                                }
                                className="cursor-pointer h-full w-full"
                              >
                                <img
                                  src={
                                    process.env.NEXT_PUBLIC_URL2 +
                                    markerInfo.files.filter(
                                      (item) => item.title == "property_images"
                                    )[0]?.address
                                  }
                                  className="w-full h-full object-cover"
                                  alt=""
                                />
                                {/* Darker Gradient Overlay for better text readability */}
                                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent" />
                              </div>
                            ) : (
                              <div
                                onClick={() =>
                                  router.push(`/land/${markerInfo.id}`)
                                }
                                className="cursor-pointer h-full w-full"
                              >
                                <img
                                  src={"/photos/noPhoto.png"}
                                  className="w-full h-full object-cover"
                                  alt=""
                                />
                                {/* Darker Gradient Overlay for better text readability */}
                                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent" />
                              </div>
                            )}

                            {/* Price Badge */}
                            <div className="absolute top-2 left-2">
                              <div className="bg-white/95 backdrop-blur-sm px-2.5 py-[0.32rem] rounded-full text-xs font-bold text-gray-800 shadow-sm">
                                {formatCurrency(
                                  markerInfo.user_defined_category
                                )}{" "}
                                ت
                              </div>
                            </div>

                            {/* Favorite Button */}
                            <div className="absolute top-2 right-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const isCurrentlyBookmarked =
                                    bookmarkedItems.has(markerInfo.id) ||
                                    markerInfo.is_favorite === 1;
                                  submitFavorite(
                                    markerInfo.id,
                                    isCurrentlyBookmarked
                                  );
                                }}
                                className={`p-1.5 rounded-full backdrop-blur-sm transition-all duration-200 shadow-sm ${
                                  bookmarkedItems.has(markerInfo.id) ||
                                  markerInfo.is_favorite === 1
                                    ? "bg-red-500 text-white shadow-lg"
                                    : "bg-white/95 text-gray-600 hover:bg-white"
                                }`}
                              >
                                {bookmarkedItems.has(markerInfo.id) ||
                                markerInfo.is_favorite === 1 ? (
                                  <BookmarkCheck
                                    size={14}
                                    fill="currentColor"
                                  />
                                ) : (
                                  <Bookmark size={14} />
                                )}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </SwiperSlide>
                    {filtered
                      ?.filter((item) => item.id !== markerInfo?.id)
                      .map((item: PropertyItem) => (
                        <SwiperSlide
                          key={item.id}
                          className="sw2"
                          style={{ width: "460px" }}
                        >
                          <div className="flex-1 rounded-2xl bg-white shadow-lg overflow-hidden mx-1 relative">
                            {selectedmarks == String(item.id) && (
                              <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-10 flex items-center justify-center rounded-2xl">
                                <div className="loader4"></div>
                              </div>
                            )}
                            <div className="flex h-40 items-center justify-between">
                              {/* Content Section */}
                              <div className="w-[60%] h-full py-3.5 px-0.5 flex flex-col justify-between">
                                {/* Title and Info */}
                                <div>
                                  <div
                                    onClick={() =>
                                      router.push(`/land/${item.id}`)
                                    }
                                    className="cursor-pointer mb-2"
                                  >
                                    <h3 className="text-base font-bold text-gray-900 leading-tight hover:text-reezAliGreen transition-colors">
                                      {item?.name?.length > 30
                                        ? item.name.slice(0, 30) + "..."
                                        : item.name}
                                    </h3>
                                  </div>

                                  {/* Location & Area */}
                                  <div className="flex items-center gap-2 text-xs text-gray-600 mb-1">
                                    <span className="font-semibold">
                                      {item?.province?.name} -{" "}
                                      {item?.city?.name}
                                    </span>
                                    <span className="text-gray-400">•</span>
                                    <span className="font-semibold">
                                      {item.area !== null
                                        ? (item.area / 10000).toFixed(1)
                                        : 0}{" "}
                                      هکتار
                                    </span>
                                  </div>

                                  {/* Harvest Status */}
                                  {item.harvesting_time && (
                                    <div className="mb-2">
                                      <div className="flex items-center gap-x-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                                        <span>🌾</span>
                                        <span>
                                          {renderHarvestStatus(
                                            item.harvesting_time
                                          )}
                                        </span>
                                      </div>
                                    </div>
                                  )}
                                </div>

                                {/* Action Buttons */}
                                <div className="flex gap-1">
                                  <Link
                                    onClick={() => setMarks(String(item.id))}
                                    href={`/land/${item.id}`}
                                    className="flex-1 bg-reezAliGreen hover:bg-reezAliGreen/90 text-white py-2.5 px-3 rounded-lg font-semibold text-xs transition-colors flex items-center justify-center gap-1"
                                  >
                                    <span>جزئیات</span>
                                    <ChevronDown size={12} />
                                  </Link>

                                  {item.user.account_status !== "مشغول" ? (
                                    <a
                                      href={`tel:+98${item?.user?.phone_number?.slice(
                                        1,
                                        12
                                      )}`}
                                      className="bg-blue-50 hover:bg-blue-100 text-blue-700 py-2.5 px-3 rounded-lg font-semibold text-xs transition-colors flex items-center justify-center gap-1"
                                    >
                                      <Phone size={12} />
                                      <span>تماس</span>
                                    </a>
                                  ) : (
                                    <span className="bg-gray-100 text-gray-500 py-2.5 px-3 rounded-lg font-semibold text-xs flex items-center justify-center gap-1">
                                      <Phone size={12} />
                                      <span>مشغول</span>
                                    </span>
                                  )}
                                </div>
                              </div>

                              {/* Image Section */}
                              <div className="relative w-[40%] h-full">
                                {item.files?.length > 0 ? (
                                  <div
                                    onClick={() =>
                                      router.push(`/land/${item.id}`)
                                    }
                                    className="cursor-pointer h-full w-full"
                                  >
                                    <img
                                      src={
                                        process.env.NEXT_PUBLIC_URL2 +
                                        item.files.filter(
                                          (item) =>
                                            item.title == "property_images"
                                        )[0]?.address
                                      }
                                      className="w-full h-full object-cover"
                                      alt=""
                                    />
                                    {/* Darker Gradient Overlay for better text readability */}
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent" />
                                  </div>
                                ) : (
                                  <div
                                    onClick={() =>
                                      router.push(`/land/${item.id}`)
                                    }
                                    className="cursor-pointer h-full w-full"
                                  >
                                    <img
                                      src={"/photos/noPhoto.png"}
                                      className="w-full h-full object-cover"
                                      alt=""
                                    />
                                    {/* Darker Gradient Overlay for better text readability */}
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent" />
                                  </div>
                                )}

                                {/* Price Badge */}
                                <div className="absolute top-2 left-2">
                                  <div className="bg-white/95 backdrop-blur-sm px-2.5 py-[0.32rem] rounded-full text-xs font-bold text-gray-800 shadow-sm">
                                    {formatCurrency(item.user_defined_category)}{" "}
                                    ت
                                  </div>
                                </div>

                                {/* Favorite Button */}
                                <div className="absolute top-2 right-2">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const isCurrentlyBookmarked =
                                        bookmarkedItems.has(item.id) ||
                                        item.is_favorite === 1;
                                      submitFavorite(
                                        item.id,
                                        isCurrentlyBookmarked
                                      );
                                    }}
                                    className={`p-1.5 rounded-full backdrop-blur-sm transition-all duration-200 shadow-sm ${
                                      bookmarkedItems.has(item.id) ||
                                      item.is_favorite === 1
                                        ? "bg-red-500 text-white shadow-lg"
                                        : "bg-white/95 text-gray-600 hover:bg-white"
                                    }`}
                                  >
                                    {bookmarkedItems.has(item.id) ||
                                    item.is_favorite === 1 ? (
                                      <BookmarkCheck
                                        size={14}
                                        fill="currentColor"
                                      />
                                    ) : (
                                      <Bookmark size={14} />
                                    )}
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </SwiperSlide>
                      ))}
                  </div>
                </Swiper>
              </div>
            </Drawer.Content>
          </Drawer.Portal>
        </Drawer.Root>
      )}
    </div>
  );
};

export default MarkersNew;

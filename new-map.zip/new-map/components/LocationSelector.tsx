import { MapPin } from "lucide-react";
import { Drawer } from "vaul";
import { Province, City } from "../types";
import { saveData } from "@/utils/IndexDb";

interface LocationSelectorProps {
  isOpen: boolean;
  setOpen: (value: boolean) => void;
  names: string | null;
  Ostan: Province[];
  city: City[];
  OstanId: string;
  setOstanId: (value: string) => void;
  cityId: string;
  setCityID: (value: string) => void;
  loadingFilter?: boolean;
}

export const LocationSelector: React.FC<LocationSelectorProps> = ({
  isOpen,
  setOpen,
  names,
  Ostan,
  city,
  OstanId,
  setOstanId,
  cityId,
  setCityID,
  loadingFilter = false,
}) => {
  return (
    <>
      <div
        onClick={() => setOpen(true)}
        className="ml-3 shadow-lg flex items-center gap-2 rounded-lg border bg-white p-2"
      >
        <MapPin className="border-l border-l-black pl-1" size={25} />
        <div className="flex gap-2">
          <span>
            {names?.length !== undefined && names?.length > 6 ? (
              <>{names?.slice(0, 6)}...</>
            ) : (
              <>{names}</>
            )}
          </span>
        </div>
      </div>
      {isOpen && (
        <Drawer.Root open={isOpen} onOpenChange={() => setOpen(false)}>
          <Drawer.Portal>
            <Drawer.Overlay className="fixed inset-0" />
            <Drawer.Content className="fixed bottom-0 left-0 right-0 z-[10000] mt-24 flex h-fit flex-col rounded-t-[10px] bg-gray-100 outline-none">
              <div className="flex-1 rounded-t-[10px] bg-white p-3">
                <div className="mx-auto max-w-md">
                  <Drawer.Title className="flex items-center justify-center gap-2 text-center text-sm text-gray-900">
                    استان یا شهر خود را وارد کنید
                  </Drawer.Title>
                  <div className="flex flex-col gap-2 rounded-md border px-3 py-3">
                    <div className="flex flex-col gap-2">
                      <label>استان</label>
                      <select
                        onChange={(e) => {
                          setOstanId(e.target.value);
                          saveData(7, e.target.value);
                          // Don't automatically clear city filter - allow both to coexist
                          // setCityID("-1");
                          // saveData(8, "-1");
                        }}
                        value={OstanId}
                        className="w-full rounded-md border p-1 px-2 focus:outline-none"
                      >
                        <option value="-1">همه ایران</option>
                        {Ostan.map((item, index) => (
                          <option key={index} value={item.name}>
                            {item.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label>شهر</label>
                      <select
                        onChange={(e) => {
                          setCityID(e.target.value);
                          saveData(8, e.target.value);
                        }}
                        value={cityId}
                        className="w-full rounded-md border p-1 px-2 focus:outline-none"
                      >
                        <option value="-1">همه</option>
                        {city.map((item, index) => (
                          <option key={index} value={item.name}>
                            {item.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <button
                    onClick={() => setOpen(false)}
                    className="mb-3 mt-3 w-full rounded-lg bg-reezAliGreen p-1 text-white"
                  >
                    {loadingFilter ? <div className="loader4"></div> : "تایید"}
                  </button>
                </div>
              </div>
            </Drawer.Content>
          </Drawer.Portal>
        </Drawer.Root>
      )}
    </>
  );
};

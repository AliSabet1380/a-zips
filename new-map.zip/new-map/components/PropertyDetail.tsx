import React, { useState, useEffect } from "react";
import { PropertyItem } from "../types";
import Link from "next/link";
import { Bookmark, BookmarkCheck, ChevronDown, Phone, X } from "lucide-react";
import Image from "next/image";
import { useFavoriteMutation } from "@/hooks/use-favorite-mutation";
import { useRouter } from "next/navigation";
import Cookies from "js-cookie";

interface PropertyDetailProps {
  property: PropertyItem;
  onClose?: () => void;
}

const PropertyDetail: React.FC<PropertyDetailProps> = ({
  property,
  onClose,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [currentProperty, setCurrentProperty] = useState(property);
  const favoriteMutation = useFavoriteMutation();
  const router = useRouter();
  const token = Cookies.get("tokens");

  const images =
    currentProperty.files
      ?.filter((f) => f.title === "property_images")
      .slice(0, 3) || [];

  // Fetch latest property data when component mounts
  useEffect(() => {
    const fetchLatestPropertyData = async () => {
      if (!token) return;

      try {
        const res = await fetch(
          process.env.NEXT_PUBLIC_BASE_URL1 + `properties/${property.id}`,
          {
            method: "GET",
            cache: "no-cache",
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const data = await res.json();
        if (data.data) {
          setCurrentProperty(data.data);
          setIsBookmarked(data.data.is_favorite === 1);
        }
      } catch (error) {
        console.error("Error fetching latest property data:", error);
      }
    };

    fetchLatestPropertyData();
  }, [property.id, token]);

  const formatCurrency = (val: string | null) => {
    if (!val) return "-";
    return Number(val).toLocaleString();
  };

  const renderHarvestStatus = (harvesting_time: string | null) => {
    if (!harvesting_time) return null;
    const inputDate = new Date(harvesting_time);
    const today = new Date();
    const diff = Math.ceil(
      (inputDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
    );
    return diff > 10 ? (
      <span className="text-green-600 font-semibold text-xs">
        {diff} روز باقی مانده تا برداشت
      </span>
    ) : (
      <span className="text-red-600 font-semibold text-xs">در حال برداشت</span>
    );
  };

  const handleBookmark = async () => {
    if (!token) {
      router.push("/auth/signout");
      return;
    }

    try {
      await favoriteMutation.mutateAsync({ property_id: currentProperty.id });
      setIsBookmarked(!isBookmarked);
    } catch (error) {
      console.error("Error toggling bookmark:", error);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg w-full overflow-hidden">
      {/* Images Row - Reduced height */}
      <div className="relative flex w-full h-20 sm:h-24 gap-1 bg-gray-100 p-1">
        {images.length > 0 ? (
          images.length === 1 ? (
            <div className="flex justify-center items-center h-full w-full mx-auto">
              <div className="rounded-lg w-full h-full">
                <Image
                  src={process.env.NEXT_PUBLIC_URL2 + images[0].address}
                  className="w-full h-full object-cover rounded-lg"
                  alt={currentProperty.name + " تصویر 1"}
                  width={100}
                  height={100}
                />
              </div>
            </div>
          ) : (
            images.map((img, idx) => (
              <div
                key={idx}
                className={`rounded-lg overflow-hidden h-full ${
                  images.length === 2 ? "w-1/2" : "w-1/3"
                }`}
              >
                <Image
                  src={process.env.NEXT_PUBLIC_URL2 + img.address}
                  className="w-full h-full object-cover"
                  alt={currentProperty.name + " تصویر " + (idx + 1)}
                  width={100}
                  height={100}
                />
              </div>
            ))
          )
        ) : (
          <Image
            src="/photos/noPhoto.png"
            className="rounded-lg object-cover w-full h-full"
            alt="بدون عکس"
            width={100}
            height={100}
          />
        )}

        {/* Close Button - Top right corner */}
        {onClose && (
          <div className="absolute top-2 right-2 rounded-md text-sm font-bold text-gray-800 shadow-sm ">
            <button
              onClick={onClose}
              className="bg-white rounded-full p-1.5 border border-gray-400 "
            >
              <X size={16} />
            </button>
          </div>
        )}
        <div className="absolute top-2 left-2 rounded-md text-sm font-bold text-gray-800 shadow-sm">
          <button
            onClick={handleBookmark}
            disabled={favoriteMutation.isPending}
            className="p-1.5 rounded-full bg-white border border-gray-400 hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            {isBookmarked ? (
              <BookmarkCheck size={16} className="text-reezAliGreen" />
            ) : (
              <Bookmark size={16} />
            )}
          </button>
        </div>
      </div>

      {/* Card Content - Compact spacing */}
      <div className="p-2.5 space-y-1">
        {/* Title - Smaller font */}
        <div className="flex justify-between items-center">
          <h2 className="text-sm font-bold text-gray-900 truncate">
            {currentProperty.name}
          </h2>

          <p className="text-xs font-bold text-gray-600">
            {formatCurrency(currentProperty.user_defined_category)}{" "}
            {currentProperty.user_defined_category != null &&
            currentProperty.user_defined_category != ""
              ? "تومان"
              : "توافقی"}
          </p>
        </div>
        {/* Location & Area - Compact */}
        <div className="flex items-center gap-1 text-xs text-gray-600">
          <span className="font-medium">
            {currentProperty.province.name} - {currentProperty.city.name}
          </span>
          <span className="text-gray-400">•</span>
          <span className="font-medium">
            {currentProperty.area !== null
              ? (currentProperty.area / 10000).toFixed(1)
              : 0}{" "}
            هکتار
          </span>
          {/* Harvest Status - Compact */}
          {currentProperty.harvesting_time && (
            <div className="flex flex-1 items-center gap-1 p-1 bg-green-50 rounded-md">
              <span className="text-xs">🌾</span>
              {renderHarvestStatus(currentProperty.harvesting_time)}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 mt-2">
          <Link
            onClick={() => setIsLoading(true)}
            href={`/land/${currentProperty.id}`}
            className="flex-1 bg-reezAliGreen hover:bg-reezAliGreen/90 text-white py-2 px-3 rounded-lg font-semibold text-xs transition-colors flex items-center justify-center gap-1"
          >
            <span>جزئیات</span>
            <ChevronDown size={12} />
          </Link>

          {currentProperty.user.account_status !== "مشغول" ? (
            <a
              href={`tel:+98${currentProperty?.user?.phone_number?.slice(
                1,
                12
              )}`}
              className="bg-blue-50 hover:bg-blue-100 text-blue-700 py-2 px-3 rounded-lg font-semibold text-xs transition-colors flex items-center justify-center gap-1"
            >
              <Phone size={12} />
              <span>تماس</span>
            </a>
          ) : (
            <span className="bg-gray-100 text-gray-500 py-2 px-3 rounded-lg font-semibold text-xs flex items-center justify-center gap-1">
              <Phone size={12} />
              <span>مشغول</span>
            </span>
          )}
        </div>
      </div>

      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-10 flex items-center justify-center rounded-xl">
          <div className="loader4"></div>
        </div>
      )}
    </div>
  );
};

export default PropertyDetail;

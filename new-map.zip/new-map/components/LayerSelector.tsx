import React, { useState } from "react";
import { Layers } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface LayerSelectorProps {
  currentMapStyle: string;
  onMapStyleChange: (style: string) => void;
}

const layerOptions = [
  {
    id: "satellite",
    name: "ماهواره‌ای",
    description: "نمایش تصاویر ماهواره‌ای",
    preview: "🛰️",
  },
  {
    id: "standard",
    name: "استاندارد",
    description: "نمایش نقشه استاندارد",
    preview: "🗺️",
  },
  {
    id: "openstreet",
    name: "OpenStreetMap",
    description: "نمایش نقشه OpenStreetMap",
    preview: "🌍",
  },
];

export const LayerSelector: React.FC<LayerSelectorProps> = ({
  currentMapStyle,
  onMapStyleChange,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleLayerSelect = (styleId: string) => {
    onMapStyleChange(styleId);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <button
          className="absolute top-16 right-3 rounded-full bg-white p-[0.7rem] shadow-lg hover:bg-gray-50 transition-colors"
          style={{ zIndex: 10001 }}
          title="انتخاب لایه نقشه"
        >
          <Layers className="text-gray-700" size={22} />
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">انتخاب لایه نقشه</DialogTitle>
        </DialogHeader>
        <div className="grid gap-3 py-4">
          {layerOptions.map((layer) => (
            <button
              key={layer.id}
              onClick={() => handleLayerSelect(layer.id)}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-all hover:bg-gray-50 ${
                currentMapStyle === layer.id
                  ? "border-reezAliGreen bg-green-50"
                  : "border-gray-200"
              }`}
            >
              <div className="text-2xl">{layer.preview}</div>
              <div className="flex-1 text-right">
                <div className="font-medium text-gray-900">{layer.name}</div>
                <div className="text-sm text-gray-500">{layer.description}</div>
              </div>
              {currentMapStyle === layer.id && (
                <div className="w-2 h-2 rounded-full bg-reezAliGreen"></div>
              )}
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};

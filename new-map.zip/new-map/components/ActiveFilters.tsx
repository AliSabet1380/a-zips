"use client";
import React from "react";
import { X } from "lucide-react";
import { Category } from "../types";

interface ActiveFiltersProps {
  categoryId: number;
  selectedCategory2Id?: number;
  selectedCategory3Id?: number;
  OstanId: string;
  cityId: string;
  searchString: string;
  filtered: Category[];
  provinces: any[];
  onClearCategory: () => void;
  onClearSubcategories: () => void;
  onClearLocation: () => void;
  onClearSearch: () => void;
  onClearAll: () => void;
}

export const ActiveFilters: React.FC<ActiveFiltersProps> = ({
  categoryId,
  selectedCategory2Id,
  selectedCategory3Id,
  OstanId,
  cityId,
  searchString,
  filtered,
  provinces,
  onClearCategory,
  onClearSubcategories,
  onClearLocation,
  onClearSearch,
  onClearAll,
}) => {
  const hasActiveFilters =
    categoryId !== 0 ||
    selectedCategory2Id ||
    selectedCategory3Id ||
    OstanId !== "-1" ||
    cityId !== "-1" ||
    searchString !== "";

  if (!hasActiveFilters) {
    return null;
  }

  // Get category name
  const getCategoryName = () => {
    const category = filtered.find((cat) => cat.id === categoryId);
    return category?.name || "";
  };

  // Get subcategory name
  const getSubcategoryName = () => {
    if (selectedCategory3Id) {
      for (const category of filtered) {
        for (const category2 of category.category2s || []) {
          for (const category3 of category2.category3s || []) {
            if (category3.id === selectedCategory3Id) {
              return `${category2.name} > ${category3.name}`;
            }
          }
        }
      }
    } else if (selectedCategory2Id) {
      for (const category of filtered) {
        for (const category2 of category.category2s || []) {
          if (category2.id === selectedCategory2Id) {
            return category2.name;
          }
        }
      }
    }
    return "";
  };

  // Get location name
  const getLocationName = () => {
    if (cityId !== "-1") {
      return cityId;
    } else if (OstanId !== "-1") {
      const province = provinces.find(
        (item: { name: string }) => item.name === OstanId
      );
      return province?.name || OstanId;
    }
    return "";
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-3 mb-4">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-semibold text-gray-700">فیلترهای فعال</h4>
        <button
          onClick={onClearAll}
          className="text-xs text-red-500 hover:text-red-700 font-medium"
        >
          پاک کردن همه
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {/* Category Filter */}
        {categoryId !== 0 && (
          <div className="flex items-center gap-1 bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
            <span>{getCategoryName()}</span>
            <button
              onClick={onClearCategory}
              className="p-1 hover:bg-blue-200 rounded-full transition-colors"
            >
              <X size={12} />
            </button>
          </div>
        )}

        {/* Subcategory Filter */}
        {(selectedCategory2Id || selectedCategory3Id) && (
          <div className="flex items-center gap-1 bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
            <span>{getSubcategoryName()}</span>
            <button
              onClick={onClearSubcategories}
              className="p-1 hover:bg-green-200 rounded-full transition-colors"
            >
              <X size={12} />
            </button>
          </div>
        )}

        {/* Location Filter */}
        {(OstanId !== "-1" || cityId !== "-1") && (
          <div className="flex items-center gap-1 bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm">
            <span>{getLocationName()}</span>
            <button
              onClick={onClearLocation}
              className="p-1 hover:bg-purple-200 rounded-full transition-colors"
            >
              <X size={12} />
            </button>
          </div>
        )}

        {/* Search Filter */}
        {searchString !== "" && (
          <div className="flex items-center gap-1 bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm">
            <span>جستجو: {searchString}</span>
            <button
              onClick={onClearSearch}
              className="p-1 hover:bg-orange-200 rounded-full transition-colors"
            >
              <X size={12} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
